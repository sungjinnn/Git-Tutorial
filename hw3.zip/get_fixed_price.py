#모듈
def get_fixed_price(discount_rate,price) :
    return price /(1-discount_rate/100)
