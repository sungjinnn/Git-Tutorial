from get_fixed_price import *

discount_rate = int(input('할인율은? '))
A_price = int(input('A 상품의 할인된 가격은? '))
A_origin_price = get_fixed_price(discount_rate,A_price)
B_price = int(input('B 상품의 할인된 가격은? '))
B_origin_price = get_fixed_price(discount_rate,B_price)
print('A 상품의 정가는',A_origin_price,'원')
print('B 상품의 정가는',B_origin_price,'원')
